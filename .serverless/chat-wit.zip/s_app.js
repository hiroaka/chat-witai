
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'rrpraxedes',
  applicationName: 'chat-wit',
  appUid: 'dKqTSkMLlgSqPGdWny',
  orgUid: 'b2b2ef77-189a-40a0-be66-6634eba43ce4',
  deploymentUid: 'bc2860a6-55f7-4068-bcaf-e292ccb0840f',
  serviceName: 'chat-wit',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'chat-wit-dev-app', timeout: 6 };

try {
  const userHandler = require('./app/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}